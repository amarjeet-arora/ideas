
export class User {
    constructor( public id = 0, public name = '', public model = '', public price = '') {}
  }

